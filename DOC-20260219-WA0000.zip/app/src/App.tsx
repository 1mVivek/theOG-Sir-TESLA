import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import './App.css';

// Sections
import Hero from './sections/Hero';
import Intro from './sections/Intro';
import ACMotor from './sections/ACMotor';
import TeslaCoil from './sections/TeslaCoil';
import Radio from './sections/Radio';
import Legacy from './sections/Legacy';
import Footer from './sections/Footer';
import LoadingScreen from './sections/LoadingScreen';
import Navigation from './sections/Navigation';
import CustomCursor from './components/CustomCursor';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    // Initialize Lenis smooth scroll
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      smoothWheel: true,
    });

    lenisRef.current = lenis;

    // Connect Lenis to GSAP ScrollTrigger
    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    // Refresh ScrollTrigger on load
    ScrollTrigger.refresh();

    return () => {
      lenis.destroy();
      gsap.ticker.remove(lenis.raf);
    };
  }, []);

  return (
    <>
      <LoadingScreen />
      <CustomCursor />
      <Navigation />
      
      <main ref={mainRef} className="relative bg-[#050505] min-h-screen">
        <Hero />
        <Intro />
        <ACMotor />
        <TeslaCoil />
        <Radio />
        <Legacy />
        <Footer />
      </main>
    </>
  );
}

export default App;
