import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Navigation = () => {
  const navRef = useRef<HTMLElement>(null);
  const [activeSection, setActiveSection] = useState('hero');
  const [isVisible, setIsVisible] = useState(false);

  const sections = [
    { id: 'hero', label: 'HOME' },
    { id: 'intro', label: 'THE MAN' },
    { id: 'ac-motor', label: 'AC MOTOR' },
    { id: 'tesla-coil', label: 'TESLA COIL' },
    { id: 'radio', label: 'RADIO' },
    { id: 'legacy', label: 'LEGACY' },
  ];

  useEffect(() => {
    const nav = navRef.current;
    if (!nav) return;

    // Show/hide navigation based on scroll
    ScrollTrigger.create({
      trigger: document.body,
      start: '100vh top',
      onEnter: () => setIsVisible(true),
      onLeaveBack: () => setIsVisible(false),
    });

    // Track active section
    sections.forEach(({ id }) => {
      ScrollTrigger.create({
        trigger: `#${id}`,
        start: 'top center',
        end: 'bottom center',
        onEnter: () => setActiveSection(id),
        onEnterBack: () => setActiveSection(id),
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      ref={navRef}
      className={`fixed right-8 top-1/2 -translate-y-1/2 z-[100] transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
      }`}
    >
      <div className="flex flex-col items-end gap-4">
        {sections.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => scrollToSection(id)}
            className="group flex items-center gap-3 transition-all duration-300"
            data-cursor-hover
          >
            {/* Label */}
            <span
              className={`text-xs tracking-widest transition-all duration-300 ${
                activeSection === id
                  ? 'text-[#00F0FF] opacity-100'
                  : 'text-white opacity-0 group-hover:opacity-60'
              }`}
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              {label}
            </span>

            {/* Indicator dot */}
            <div
              className={`w-3 h-3 rounded-full border-2 transition-all duration-300 ${
                activeSection === id
                  ? 'border-[#00F0FF] bg-[#00F0FF] scale-125'
                  : 'border-white/40 bg-transparent group-hover:border-[#00F0FF]/60'
              }`}
              style={
                activeSection === id
                  ? { boxShadow: '0 0 10px #00F0FF, 0 0 20px #00F0FF' }
                  : {}
              }
            />
          </button>
        ))}
      </div>

      {/* Progress line */}
      <div className="absolute right-[5px] top-0 bottom-0 w-[2px] bg-white/10 -z-10">
        <div
          className="w-full bg-[#00F0FF] transition-all duration-300"
          style={{
            height: `${
              ((sections.findIndex((s) => s.id === activeSection) + 1) /
                sections.length) *
              100
            }%`,
            boxShadow: '0 0 10px #00F0FF',
          }}
        />
      </div>
    </nav>
  );
};

export default Navigation;
