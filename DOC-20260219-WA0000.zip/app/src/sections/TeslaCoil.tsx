import { useEffect, useRef, Suspense, useMemo } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import * as THREE from 'three';

gsap.registerPlugin(ScrollTrigger);

// Spark particles component
const ElectricSparks = ({ intensity }: { intensity: number }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const sparkCount = 200;

  const [positions, velocities] = useMemo(() => {
    const pos = new Float32Array(sparkCount * 3);
    const vel = new Float32Array(sparkCount * 3);

    for (let i = 0; i < sparkCount; i++) {
      // Start from top of coil
      pos[i * 3] = (Math.random() - 0.5) * 2;
      pos[i * 3 + 1] = 6 + Math.random() * 2;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 2;

      // Random outward velocity
      vel[i * 3] = (Math.random() - 0.5) * 0.3;
      vel[i * 3 + 1] = Math.random() * 0.3;
      vel[i * 3 + 2] = (Math.random() - 0.5) * 0.3;
    }

    return [pos, vel];
  }, []);

  useFrame(() => {
    if (!pointsRef.current) return;

    const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;

    for (let i = 0; i < sparkCount; i++) {
      // Update position
      positions[i * 3] += velocities[i * 3] * intensity;
      positions[i * 3 + 1] += velocities[i * 3 + 1] * intensity;
      positions[i * 3 + 2] += velocities[i * 3 + 2] * intensity;

      // Reset if too far
      const dist = Math.sqrt(
        positions[i * 3] ** 2 +
        (positions[i * 3 + 1] - 6) ** 2 +
        positions[i * 3 + 2] ** 2
      );

      if (dist > 8 || positions[i * 3 + 1] > 12) {
        positions[i * 3] = (Math.random() - 0.5) * 2;
        positions[i * 3 + 1] = 6 + Math.random();
        positions[i * 3 + 2] = (Math.random() - 0.5) * 2;
      }
    }

    pointsRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.15}
        color="#00F0FF"
        transparent
        opacity={0.8}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

// Tesla Coil 3D Model - Enhanced with brighter materials
const TeslaCoilModel = ({ sparkIntensity }: { sparkIntensity: number }) => {
  return (
    <group>
      {/* Base platform - lighter color */}
      <mesh position={[0, -4, 0]}>
        <cylinderGeometry args={[4, 4.5, 1, 32]} />
        <meshStandardMaterial
          color="#4A4A4A"
          metalness={0.7}
          roughness={0.3}
        />
      </mesh>

      {/* Primary coil (bottom) - brighter wood */}
      <mesh position={[0, -2, 0]}>
        <cylinderGeometry args={[2.5, 2.5, 3, 32]} />
        <meshStandardMaterial
          color="#A0522D"
          metalness={0.5}
          roughness={0.5}
        />
      </mesh>

      {/* Copper windings on primary - brighter */}
      {[...Array(15)].map((_, i) => (
        <mesh key={i} position={[0, -3.2 + i * 0.2, 0]}>
          <torusGeometry args={[2.55, 0.05, 8, 32]} />
          <meshStandardMaterial
            color="#E8A858"
            metalness={0.95}
            roughness={0.15}
          />
        </mesh>
      ))}

      {/* Secondary coil (tall) - brighter gold */}
      <mesh position={[0, 2, 0]}>
        <cylinderGeometry args={[0.8, 0.8, 8, 32]} />
        <meshStandardMaterial
          color="#FFD700"
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Secondary windings - brighter copper */}
      {[...Array(40)].map((_, i) => (
        <mesh key={i} position={[0, -1.5 + i * 0.15, 0]}>
          <torusGeometry args={[0.85, 0.02, 6, 24]} />
          <meshStandardMaterial
            color="#E8A858"
            metalness={0.95}
            roughness={0.15}
          />
        </mesh>
      ))}

      {/* Torus (donut) top - shiny chrome */}
      <mesh position={[0, 6, 0]}>
        <torusGeometry args={[2, 0.6, 16, 48]} />
        <meshStandardMaterial
          color="#E8E8E8"
          metalness={0.95}
          roughness={0.05}
        />
      </mesh>

      {/* Metal ball on top - glowing */}
      <mesh position={[0, 7, 0]}>
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial
          color="#FFFFFF"
          metalness={0.98}
          roughness={0.02}
          emissive="#00F0FF"
          emissiveIntensity={0.3}
        />
      </mesh>

      {/* Support structure */}
      <mesh position={[2.5, 2, 0]} rotation={[0, 0, -0.1]}>
        <cylinderGeometry args={[0.1, 0.1, 8, 8]} />
        <meshStandardMaterial color="#6A6A6A" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[-2.5, 2, 0]} rotation={[0, 0, 0.1]}>
        <cylinderGeometry args={[0.1, 0.1, 8, 8]} />
        <meshStandardMaterial color="#6A6A6A" metalness={0.6} roughness={0.4} />
      </mesh>

      {/* Electric sparks */}
      <ElectricSparks intensity={sparkIntensity} />
    </group>
  );
};

const TeslaCoil = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const sparkIntensityRef = useRef(0.5);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const text = textRef.current;
    const canvasContainer = canvasContainerRef.current;

    if (!section || !heading || !text || !canvasContainer) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(
        heading,
        { opacity: 0, x: -100 },
        {
          opacity: 1,
          x: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Text animation
      gsap.fromTo(
        text,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Canvas rise animation
      gsap.fromTo(
        canvasContainer,
        { opacity: 0, y: 100 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Spark intensity based on scroll
      ScrollTrigger.create({
        trigger: section,
        start: 'top bottom',
        end: 'bottom top',
        scrub: 1,
        onUpdate: (self) => {
          sparkIntensityRef.current = 0.5 + self.progress * 2;
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="tesla-coil"
      className="relative w-full min-h-screen bg-[#050505] py-20 overflow-hidden"
    >
      {/* Electric background effect */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(0, 240, 255, 0.15) 0%, transparent 70%)',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-8 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center min-h-[80vh]">
          {/* Left: Vertical heading */}
          <div className="lg:col-span-2 order-1">
            <h2
              ref={headingRef}
              className="text-5xl lg:text-7xl font-black text-[#00F0FF] tracking-tight lg:writing-mode-vertical lg:rotate-180"
              style={{
                fontFamily: 'Orbitron, sans-serif',
                writingMode: 'vertical-rl',
                textOrientation: 'mixed',
              }}
            >
              TESLA COIL
            </h2>
          </div>

          {/* Center: 3D Model */}
          <div className="lg:col-span-6 order-3 lg:order-2">
            <div
              ref={canvasContainerRef}
              className="relative h-[500px] lg:h-[700px]"
              style={{ touchAction: 'pan-y' }}
            >
              <Canvas className="w-full h-full">
                <PerspectiveCamera makeDefault position={[0, 2, 15]} />
                <OrbitControls
                  enableZoom={false}
                  enablePan={false}
                  autoRotate
                  autoRotateSpeed={0.5}
                  minPolarAngle={Math.PI / 4}
                  maxPolarAngle={Math.PI / 1.5}
                  enableDamping={false}
                />
                
                {/* Enhanced lighting */}
                <ambientLight intensity={0.7} />
                
                {/* Main cyan light */}
                <pointLight position={[8, 8, 10]} intensity={2} color="#00F0FF" />
                
                {/* Warm fill light */}
                <pointLight position={[-8, 5, 8]} intensity={1.5} color="#FFD700" />
                
                {/* White rim light */}
                <pointLight position={[0, 10, -8]} intensity={1.2} color="#FFFFFF" />
                
                {/* Bottom glow */}
                <pointLight position={[0, -8, 5]} intensity={1} color="#00F0FF" />
                
                {/* Directional light */}
                <directionalLight position={[5, 10, 5]} intensity={1.2} color="#FFFFFF" />
                
                <Suspense fallback={null}>
                  <TeslaCoilModel sparkIntensity={sparkIntensityRef.current} />
                  <Environment preset="city" />
                </Suspense>
              </Canvas>

              {/* Glow overlay */}
              <div
                className="absolute inset-0 pointer-events-none rounded-lg"
                style={{
                  boxShadow: 'inset 0 0 100px rgba(0, 240, 255, 0.3), 0 0 40px rgba(0, 240, 255, 0.2)',
                }}
              />
            </div>
          </div>

          {/* Right: Content */}
          <div className="lg:col-span-4 order-2 lg:order-3 space-y-6">
            <div ref={textRef}>
              <p className="text-lg text-white/80 leading-relaxed mb-6" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                Invented in 1891, the Tesla Coil is a resonant transformer circuit that produces 
                high-voltage, high-frequency alternating current electricity. It creates spectacular 
                electrical discharges that can light up the night sky.
              </p>

              <p className="text-lg text-white/80 leading-relaxed mb-6" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                At his Colorado Springs laboratory in 1899, Tesla created man-made lightning 
                measuring over 41 meters (135 feet) long. The coil remains fundamental to radio 
                technology, television sets, and medical devices today.
              </p>

              {/* Specifications */}
              <div className="border border-[#00F0FF]/30 rounded-lg p-6 bg-[#00F0FF]/5">
                <h4 className="text-[#00F0FF] text-sm tracking-widest mb-4" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                  SPECIFICATIONS
                </h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-white/60">Output Voltage</span>
                    <span className="text-white">1,000,000+ Volts</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Frequency</span>
                    <span className="text-white">50-500 kHz</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Spark Length</span>
                    <span className="text-white">Up to 41 meters</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Primary Winding</span>
                    <span className="text-white">Copper tubing</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative arcs */}
      <svg
        className="absolute top-10 right-10 w-64 h-64 opacity-20"
        viewBox="0 0 200 200"
      >
        <path
          d="M100 0 Q150 50 100 100 Q50 150 100 200"
          fill="none"
          stroke="#00F0FF"
          strokeWidth="2"
        />
        <path
          d="M120 20 Q170 70 120 120 Q70 170 120 220"
          fill="none"
          stroke="#00F0FF"
          strokeWidth="1"
        />
      </svg>
    </section>
  );
};

export default TeslaCoil;
