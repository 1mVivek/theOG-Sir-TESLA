import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Intro = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const text = textRef.current;
    const image = imageRef.current;
    const frame = frameRef.current;

    if (!section || !heading || !text || !image || !frame) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(
        heading,
        { opacity: 0, x: -100 },
        {
          opacity: 1,
          x: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Text paragraphs animation
      const paragraphs = text.querySelectorAll('p');
      paragraphs.forEach((p, i) => {
        gsap.fromTo(
          p,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: i * 0.2,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 60%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });

      // Image frame animation
      gsap.fromTo(
        frame,
        { opacity: 0, scale: 0.9, rotateY: -15 },
        {
          opacity: 1,
          scale: 1,
          rotateY: 0,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Electric border pulse
      gsap.to(frame, {
        boxShadow: '0 0 30px rgba(0, 240, 255, 0.6), inset 0 0 20px rgba(0, 240, 255, 0.2)',
        duration: 1.5,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="intro"
      className="relative w-full min-h-screen bg-[#050505] py-20 overflow-hidden"
    >
      {/* Background grid */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 240, 255, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 240, 255, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-8 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center min-h-[80vh]">
          {/* Left: Text content */}
          <div className="space-y-8">
            <h2
              ref={headingRef}
              className="text-4xl md:text-6xl font-bold text-white leading-tight"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              THE MAN WHO
              <span className="block electric-text">LIT THE WORLD</span>
            </h2>

            <div ref={textRef} className="space-y-6">
              <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                Born on July 10, 1856, in Smiljan, Croatia, Nikola Tesla was a visionary inventor 
                who revolutionized the way we generate and use electricity. His genius paved the 
                way for the modern world as we know it.
              </p>

              <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                With an eidetic memory and the ability to visualize inventions in complete detail 
                before building them, Tesla held over 300 patents and spoke eight languages. He 
                arrived in America in 1884 with just four cents in his pocket, a few poems, and 
                calculations for a flying machine.
              </p>

              <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                Despite his brilliance, Tesla died nearly penniless in 1943. Yet his legacy lives 
                on in every light switch we flip, every wireless device we use, and every electric 
                motor that powers our world.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="text-4xl font-bold electric-text" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                    300+
                  </div>
                  <div className="text-sm text-white/50 uppercase tracking-wider mt-2">Patents</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold electric-text" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                    8
                  </div>
                  <div className="text-sm text-white/50 uppercase tracking-wider mt-2">Languages</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold electric-text" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                    1856
                  </div>
                  <div className="text-sm text-white/50 uppercase tracking-wider mt-2">Born</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Image with electric frame */}
          <div ref={imageRef} className="relative perspective-1000">
            <div
              ref={frameRef}
              className="relative p-2 rounded-lg"
              style={{
                border: '2px solid rgba(0, 240, 255, 0.5)',
                boxShadow: '0 0 20px rgba(0, 240, 255, 0.3), inset 0 0 20px rgba(0, 240, 255, 0.1)',
              }}
            >
              <img
                src="/tesla-lab.jpg"
                alt="Tesla in his laboratory"
                className="w-full h-auto rounded"
              />

              {/* Corner accents */}
              <div className="absolute -top-2 -left-2 w-8 h-8 border-l-4 border-t-4 border-[#00F0FF]" />
              <div className="absolute -top-2 -right-2 w-8 h-8 border-r-4 border-t-4 border-[#00F0FF]" />
              <div className="absolute -bottom-2 -left-2 w-8 h-8 border-l-4 border-b-4 border-[#00F0FF]" />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 border-r-4 border-b-4 border-[#00F0FF]" />
            </div>

            {/* Floating label */}
            <div
              className="absolute -bottom-6 -right-6 bg-[#050505] border border-[#00F0FF]/50 px-6 py-3 rounded"
              style={{ boxShadow: '0 0 20px rgba(0, 240, 255, 0.2)' }}
            >
              <span className="text-[#00F0FF] text-sm tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                COLORADO SPRINGS, 1899
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Intro;
