import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const portraitRef = useRef<HTMLImageElement>(null);
  const lightningRef = useRef<SVGPathElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subheadingRef = useRef<HTMLHeadingElement>(null);
  const outlineTextRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const portrait = portraitRef.current;
    const lightning = lightningRef.current;
    const heading = headingRef.current;
    const subheading = subheadingRef.current;
    const outlineText = outlineTextRef.current;

    if (!section || !portrait || !lightning || !heading || !subheading || !outlineText) return;

    const ctx = gsap.context(() => {
      // Initial reveal animation
      const revealTl = gsap.timeline({ delay: 2.5 }); // Wait for loading screen

      // Portrait fade in and scale
      revealTl.fromTo(
        portrait,
        { opacity: 0, scale: 1.1 },
        { opacity: 1, scale: 1, duration: 1.2, ease: 'power2.out' }
      );

      // Lightning draw animation
      const lightningLength = lightning.getTotalLength();
      gsap.set(lightning, {
        strokeDasharray: lightningLength,
        strokeDashoffset: lightningLength,
      });

      revealTl.to(
        lightning,
        {
          strokeDashoffset: 0,
          duration: 0.6,
          ease: 'power2.inOut',
        },
        '-=0.5'
      );

      // Outline text reveal
      revealTl.fromTo(
        outlineText,
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' },
        '-=0.3'
      );

      // Main heading slide up
      revealTl.fromTo(
        heading,
        { opacity: 0, y: 80 },
        { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' },
        '-=0.4'
      );

      // Subheading
      revealTl.fromTo(
        subheading,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.6, ease: 'power2.out' },
        '-=0.3'
      );

      // Lightning flicker loop
      gsap.to(lightning, {
        opacity: 0.7,
        duration: 0.05,
        repeat: -1,
        yoyo: true,
        ease: 'steps(2)',
      });

      // Portrait breathing animation
      gsap.to(portrait, {
        scale: 1.02,
        duration: 4,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      // Scroll-based exit animation
      ScrollTrigger.create({
        trigger: section,
        start: 'top top',
        end: '+=100%',
        pin: true,
        scrub: 1,
        onUpdate: (self) => {
          const progress = self.progress;
          if (progress > 0.5) {
            const exitProgress = (progress - 0.5) * 2;
            gsap.to(section, {
              opacity: 1 - exitProgress,
              scale: 1 + exitProgress * 0.1,
              duration: 0.1,
            });
          }
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative w-full h-screen bg-[#050505] overflow-hidden flex items-center justify-center"
    >
      {/* Background particles */}
      <div className="absolute inset-0 opacity-30">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[#00F0FF] rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${1 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Outline text background */}
      <h1
        ref={outlineTextRef}
        className="absolute text-[15vw] font-black text-outline opacity-20 tracking-tight select-none"
        style={{ fontFamily: 'Orbitron, sans-serif' }}
      >
        NIKOLA TESLA
      </h1>

      {/* Tesla Portrait */}
      <div className="relative z-10 flex flex-col items-center">
        <div className="relative">
          <img
            ref={portraitRef}
            src="/tesla-portrait.png"
            alt="Nikola Tesla"
            className="w-[40vw] max-w-[500px] h-auto object-contain relative z-10"
          />

          {/* Lightning SVG overlay */}
          <svg
            className="absolute inset-0 w-full h-full z-20 pointer-events-none"
            viewBox="0 0 500 700"
            preserveAspectRatio="xMidYMid slice"
          >
            <defs>
              <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="4" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <path
              ref={lightningRef}
              d="M400 50 L350 150 L380 180 L300 280 L340 320 L250 450 L290 500 L200 650"
              fill="none"
              stroke="#00F0FF"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#glow)"
              className="drop-shadow-[0_0_15px_rgba(0,240,255,0.8)]"
            />
          </svg>

          {/* Glow effect behind portrait */}
          <div className="absolute inset-0 bg-gradient-radial from-[#00F0FF]/10 via-transparent to-transparent blur-3xl -z-10" />
        </div>

        {/* Main heading */}
        <h2
          ref={headingRef}
          className="mt-8 text-6xl md:text-8xl font-black electric-text tracking-wider"
          style={{ fontFamily: 'Orbitron, sans-serif' }}
        >
          THE OG
        </h2>

        {/* Subheading */}
        <p
          ref={subheadingRef}
          className="mt-4 text-lg md:text-xl text-white/60 tracking-[0.3em] uppercase"
          style={{ fontFamily: 'Rajdhani, sans-serif' }}
        >
          Master of Lightning
        </p>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#050505] to-transparent z-30" />

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 w-24 h-24 border-l-2 border-t-2 border-[#00F0FF]/30" />
      <div className="absolute top-8 right-8 w-24 h-24 border-r-2 border-t-2 border-[#00F0FF]/30" />
      <div className="absolute bottom-8 left-8 w-24 h-24 border-l-2 border-b-2 border-[#00F0FF]/30" />
      <div className="absolute bottom-8 right-8 w-24 h-24 border-r-2 border-b-2 border-[#00F0FF]/30" />
    </section>
  );
};

export default Hero;
