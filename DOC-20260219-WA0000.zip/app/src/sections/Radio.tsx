import { useEffect, useRef, Suspense, useMemo } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import * as THREE from 'three';

gsap.registerPlugin(ScrollTrigger);

// Radio wave rings
const RadioWaves = ({ progress }: { progress: number }) => {
  const groupRef = useRef<THREE.Group>(null);

  const rings = useMemo(() => {
    return [...Array(5)].map((_, i) => ({
      id: i,
      delay: i * 0.5,
      scale: 1 + i * 0.5,
    }));
  }, []);

  useFrame((state) => {
    if (!groupRef.current) return;

    rings.forEach((ring, i) => {
      const mesh = groupRef.current?.children[i] as THREE.Mesh;
      if (mesh) {
        const scale = 1 + ((state.clock.elapsedTime * 2 + ring.delay) % 5) * progress * 2;
        mesh.scale.setScalar(scale);
        const material = mesh.material as THREE.MeshBasicMaterial;
        material.opacity = Math.max(0, 1 - (scale - 1) / 8) * 0.5;
      }
    });
  });

  return (
    <group ref={groupRef}>
      {rings.map((ring) => (
        <mesh key={ring.id} rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[2, 2.1, 64]} />
          <meshBasicMaterial
            color="#00F0FF"
            transparent
            opacity={0.5}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
};

// Wireless boat model (Teleautomaton) - Enhanced with better visibility
const WirelessBoat = () => {
  return (
    <group>
      {/* Boat hull - brighter wood color */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[4, 1, 2]} />
        <meshStandardMaterial 
          color="#A0522D" 
          metalness={0.4} 
          roughness={0.5}
        />
      </mesh>

      {/* Deck */}
      <mesh position={[0, 0.6, 0]}>
        <boxGeometry args={[3.8, 0.2, 1.8]} />
        <meshStandardMaterial 
          color="#8B4513" 
          metalness={0.3} 
          roughness={0.6}
        />
      </mesh>

      {/* Cabin - lighter color */}
      <mesh position={[0, 1.2, 0]}>
        <boxGeometry args={[1.5, 1, 1]} />
        <meshStandardMaterial 
          color="#606060" 
          metalness={0.5} 
          roughness={0.5}
        />
      </mesh>

      {/* Cabin roof - metallic */}
      <mesh position={[0, 1.75, 0]}>
        <boxGeometry args={[1.7, 0.1, 1.2]} />
        <meshStandardMaterial 
          color="#C0C0C0" 
          metalness={0.9} 
          roughness={0.2}
        />
      </mesh>

      {/* Antenna mast */}
      <mesh position={[0, 3, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 4, 8]} />
        <meshStandardMaterial 
          color="#E0E0E0" 
          metalness={0.9} 
          roughness={0.1}
        />
      </mesh>

      {/* Antenna ball - glowing */}
      <mesh position={[0, 4.8, 0]}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial
          color="#00F0FF"
          emissive="#00F0FF"
          emissiveIntensity={1}
        />
      </mesh>

      {/* Propeller - brass */}
      <mesh position={[-2.2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.4, 0.4, 0.1, 16]} />
        <meshStandardMaterial 
          color="#FFD700" 
          metalness={0.9} 
          roughness={0.2}
        />
      </mesh>

      {/* Light on cabin - glowing */}
      <mesh position={[0.6, 1.5, 0]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshStandardMaterial
          color="#00F0FF"
          emissive="#00F0FF"
          emissiveIntensity={2}
        />
      </mesh>

      {/* Additional glowing details */}
      <mesh position={[-0.6, 1.5, 0]}>
        <sphereGeometry args={[0.1, 16, 16]} />
        <meshStandardMaterial
          color="#FFFFFF"
          emissive="#FFFFFF"
          emissiveIntensity={1}
        />
      </mesh>

      {/* Side lights */}
      <mesh position={[0, 0.3, 1.1]}>
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial
          color="#00F0FF"
          emissive="#00F0FF"
          emissiveIntensity={1.5}
        />
      </mesh>
      <mesh position={[0, 0.3, -1.1]}>
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial
          color="#00F0FF"
          emissive="#00F0FF"
          emissiveIntensity={1.5}
        />
      </mesh>

      {/* Front light */}
      <mesh position={[2.1, 0.3, 0]}>
        <sphereGeometry args={[0.1, 16, 16]} />
        <meshStandardMaterial
          color="#FFFFFF"
          emissive="#FFFFFF"
          emissiveIntensity={1.5}
        />
      </mesh>
    </group>
  );
};

const Radio = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subheadingRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const waveProgressRef = useRef(0);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const subheading = subheadingRef.current;
    const text = textRef.current;
    const canvasContainer = canvasContainerRef.current;

    if (!section || !heading || !subheading || !text || !canvasContainer) return;

    const ctx = gsap.context(() => {
      // Heading animations
      gsap.fromTo(
        heading,
        { opacity: 0, y: -50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        subheading,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        text,
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          delay: 0.4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        canvasContainer,
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1,
          scale: 1,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Wave progress based on scroll
      ScrollTrigger.create({
        trigger: section,
        start: 'top bottom',
        end: 'bottom top',
        scrub: 1,
        onUpdate: (self) => {
          waveProgressRef.current = self.progress;
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="radio"
      className="relative w-full min-h-screen bg-[#050505] py-20 overflow-hidden"
    >
      {/* Vintage newspaper texture overlay */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Ctext x='10' y='20' font-size='8' fill='%2300F0FF' opacity='0.3'%3E NEWS %3C/text%3E%3C/svg%3E")`,
          backgroundSize: '50px 50px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-8 lg:px-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            ref={headingRef}
            className="text-5xl md:text-7xl font-black text-outline-cyan tracking-tight"
            style={{ fontFamily: 'Orbitron, sans-serif' }}
          >
            WIRELESS
            <span className="block">TRANSMISSION</span>
          </h2>
          <h3
            ref={subheadingRef}
            className="mt-4 text-3xl md:text-4xl text-[#00F0FF] tracking-widest"
            style={{ fontFamily: 'Orbitron, sans-serif' }}
          >
            RADIO
          </h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: 3D Model */}
          <div
            ref={canvasContainerRef}
            className="relative h-[400px] lg:h-[500px]"
            style={{ touchAction: 'pan-y' }}
          >
            <Canvas className="w-full h-full">
              <PerspectiveCamera makeDefault position={[0, 3, 12]} />
              <OrbitControls
                enableZoom={false}
                enablePan={false}
                autoRotate
                autoRotateSpeed={1}
                enableDamping={false}
              />
              
              {/* Enhanced lighting setup */}
              <ambientLight intensity={0.6} />
              
              {/* Main cyan light from front */}
              <pointLight position={[5, 5, 10]} intensity={2} color="#00F0FF" />
              
              {/* Warm light from side */}
              <pointLight position={[-8, 3, 5]} intensity={1.5} color="#FFD700" />
              
              {/* White fill light */}
              <pointLight position={[0, 8, -5]} intensity={1} color="#FFFFFF" />
              
              {/* Bottom glow */}
              <pointLight position={[0, -5, 5]} intensity={1} color="#00F0FF" />
              
              {/* Directional light for shadows */}
              <directionalLight position={[5, 10, 5]} intensity={1} color="#FFFFFF" />
              
              <Suspense fallback={null}>
                <WirelessBoat />
                <RadioWaves progress={waveProgressRef.current} />
                <Environment preset="city" />
              </Suspense>
            </Canvas>

            {/* Glow effect */}
            <div
              className="absolute inset-0 pointer-events-none rounded-lg"
              style={{
                boxShadow: 'inset 0 0 80px rgba(0, 240, 255, 0.3), 0 0 40px rgba(0, 240, 255, 0.2)',
              }}
            />

            {/* Label */}
            <div className="absolute bottom-4 left-4 text-xs text-[#00F0FF]/60 tracking-widest">
              FIG. 2 - TELEAUTOMATON (1898)
            </div>
          </div>

          {/* Right: Content */}
          <div ref={textRef} className="space-y-6">
            <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              In 1898, Tesla demonstrated the world's first radio-controlled vessel—a 
              teleautomaton boat—at Madison Square Garden. He envisioned a future where 
              wireless technology would connect the entire world.
            </p>

            <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              Tesla's experiments with radio-frequency waves laid the foundation for modern 
              radio, radar, and wireless communication. He suggested using radio waves to 
              detect ships—a concept later developed as RADAR.
            </p>

            {/* Timeline */}
            <div className="border-l-2 border-[#00F0FF]/30 pl-6 space-y-6 mt-8">
              <div className="relative">
                <div className="absolute -left-[31px] w-4 h-4 rounded-full bg-[#00F0FF]" />
                <div className="text-[#00F0FF] text-sm mb-1">1893</div>
                <div className="text-white/80">First public demonstration of wireless transmission</div>
              </div>
              <div className="relative">
                <div className="absolute -left-[31px] w-4 h-4 rounded-full bg-[#00F0FF]" />
                <div className="text-[#00F0FF] text-sm mb-1">1898</div>
                <div className="text-white/80">Radio-controlled boat (Teleautomaton)</div>
              </div>
              <div className="relative">
                <div className="absolute -left-[31px] w-4 h-4 rounded-full bg-[#00F0FF]" />
                <div className="text-[#00F0FF] text-sm mb-1">1900</div>
                <div className="text-white/80">Wardenclyffe Tower project begins</div>
              </div>
            </div>

            {/* Quote */}
            <div className="mt-8 p-6 border border-[#00F0FF]/30 rounded-lg bg-[#00F0FF]/5">
              <p className="text-white/90 italic" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                "When wireless is perfectly applied, the whole earth will be converted into 
                a huge brain... We shall be able to communicate with one another instantly, 
                irrespective of distance."
              </p>
              <p className="text-[#00F0FF] text-sm mt-3">— Nikola Tesla, 1926</p>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative wave pattern */}
      <svg
        className="absolute bottom-0 left-0 w-full h-32 opacity-10"
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
      >
        <path
          d="M0,60 Q300,0 600,60 T1200,60 L1200,120 L0,120 Z"
          fill="#00F0FF"
        />
      </svg>
    </section>
  );
};

export default Radio;
