import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

const LoadingScreen = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const container = containerRef.current;
    const progress = progressRef.current;
    const text = textRef.current;
    if (!container || !progress || !text) return;

    const tl = gsap.timeline({
      onComplete: () => {
        setIsLoading(false);
        container.style.display = 'none';
      },
    });

    // Animate progress bar
    tl.to(progress, {
      width: '100%',
      duration: 2,
      ease: 'power2.inOut',
    });

    // Text scramble effect
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const originalText = 'INITIALIZING...';
    let iteration = 0;

    const interval = setInterval(() => {
      text.innerText = originalText
        .split('')
        .map((_, index) => {
          if (index < iteration) {
            return originalText[index];
          }
          return chars[Math.floor(Math.random() * chars.length)];
        })
        .join('');

      if (iteration >= originalText.length) {
        clearInterval(interval);
      }

      iteration += 1 / 3;
    }, 30);

    // Exit animation
    tl.to(container, {
      opacity: 0,
      duration: 0.5,
      delay: 0.3,
      ease: 'power2.in',
    });

    return () => {
      clearInterval(interval);
    };
  }, []);

  if (!isLoading) return null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[10000] bg-[#050505] flex flex-col items-center justify-center"
    >
      {/* Electric circuit background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M0 50 L30 50 L30 20 L50 20" fill="none" stroke="#00F0FF" strokeWidth="1" />
              <path d="M50 0 L50 30 L80 30 L80 50" fill="none" stroke="#00F0FF" strokeWidth="1" />
              <circle cx="50" cy="20" r="3" fill="#00F0FF" />
              <circle cx="80" cy="50" r="3" fill="#00F0FF" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#circuit)" />
        </svg>
      </div>

      {/* Loading content */}
      <div className="relative z-10 flex flex-col items-center gap-8">
        {/* Electric logo */}
        <div className="relative">
          <svg width="80" height="120" viewBox="0 0 80 120" className="animate-pulse">
            <path
              d="M40 0 L10 50 L35 50 L20 120 L70 50 L45 50 L60 0 Z"
              fill="none"
              stroke="#00F0FF"
              strokeWidth="3"
              className="electric-glow"
            />
          </svg>
          <div className="absolute inset-0 blur-xl">
            <svg width="80" height="120" viewBox="0 0 80 120">
              <path
                d="M40 0 L10 50 L35 50 L20 120 L70 50 L45 50 L60 0 Z"
                fill="#00F0FF"
                opacity="0.5"
              />
            </svg>
          </div>
        </div>

        {/* Loading text */}
        <div
          ref={textRef}
          className="text-2xl font-bold tracking-[0.3em] text-[#00F0FF]"
          style={{ fontFamily: 'Orbitron, sans-serif' }}
        >
          INITIALIZING...
        </div>

        {/* Progress bar */}
        <div className="w-64 h-1 bg-[#1A1A1A] rounded-full overflow-hidden">
          <div
            ref={progressRef}
            className="h-full bg-gradient-to-r from-[#00F0FF] to-[#00a0ff]"
            style={{ width: '0%', boxShadow: '0 0 20px #00F0FF' }}
          />
        </div>

        {/* Percentage */}
        <div className="text-sm text-[#00F0FF] opacity-60" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
          SYSTEM BOOT
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 w-16 h-16 border-l-2 border-t-2 border-[#00F0FF] opacity-50" />
      <div className="absolute top-8 right-8 w-16 h-16 border-r-2 border-t-2 border-[#00F0FF] opacity-50" />
      <div className="absolute bottom-8 left-8 w-16 h-16 border-l-2 border-b-2 border-[#00F0FF] opacity-50" />
      <div className="absolute bottom-8 right-8 w-16 h-16 border-r-2 border-b-2 border-[#00F0FF] opacity-50" />
    </div>
  );
};

export default LoadingScreen;
