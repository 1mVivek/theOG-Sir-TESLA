import { useEffect, useRef, Suspense } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';

gsap.registerPlugin(ScrollTrigger);

// 3D AC Motor Component
const ACMotorModel = ({ rotationY }: { rotationY: number }) => {
  return (
    <group rotation={[0, rotationY * 0.5, 0]}>
      {/* Motor housing */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[2, 2, 4, 32]} />
        <meshStandardMaterial
          color="#8B7355"
          metalness={0.8}
          roughness={0.3}
        />
      </mesh>

      {/* End caps */}
      <mesh position={[0, 2.2, 0]}>
        <cylinderGeometry args={[2.1, 2.1, 0.4, 32]} />
        <meshStandardMaterial
          color="#5C4A3A"
          metalness={0.7}
          roughness={0.4}
        />
      </mesh>
      <mesh position={[0, -2.2, 0]}>
        <cylinderGeometry args={[2.1, 2.1, 0.4, 32]} />
        <meshStandardMaterial
          color="#5C4A3A"
          metalness={0.7}
          roughness={0.4}
        />
      </mesh>

      {/* Copper windings (visible section) */}
      <mesh position={[0, 0, 2.05]}>
        <torusGeometry args={[1.5, 0.3, 16, 32]} />
        <meshStandardMaterial
          color="#B87333"
          metalness={0.9}
          roughness={0.2}
        />
      </mesh>

      {/* Shaft */}
      <mesh position={[0, 3, 0]}>
        <cylinderGeometry args={[0.3, 0.3, 1.5, 16]} />
        <meshStandardMaterial
          color="#C0C0C0"
          metalness={0.95}
          roughness={0.1}
        />
      </mesh>

      {/* Cooling fins */}
      {[...Array(12)].map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 12) * Math.PI * 2) * 2.2,
            0,
            Math.sin((i / 12) * Math.PI * 2) * 2.2,
          ]}
          rotation={[0, (i / 12) * Math.PI * 2, 0]}
        >
          <boxGeometry args={[0.1, 3.5, 0.3]} />
          <meshStandardMaterial
            color="#6B5B4F"
            metalness={0.6}
            roughness={0.5}
          />
        </mesh>
      ))}

      {/* Mounting base */}
      <mesh position={[0, -3, 1]}>
        <boxGeometry args={[3, 0.5, 2]} />
        <meshStandardMaterial
          color="#4A4A4A"
          metalness={0.5}
          roughness={0.6}
        />
      </mesh>

      {/* Bolts */}
      {[-1.2, 1.2].map((x, i) => (
        <mesh key={i} position={[x, -2.7, 1.8]}>
          <cylinderGeometry args={[0.15, 0.15, 0.3, 8]} />
          <meshStandardMaterial
            color="#C0C0C0"
            metalness={0.9}
            roughness={0.2}
          />
        </mesh>
      ))}
    </group>
  );
};

const ACMotor = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subheadingRef = useRef<HTMLHeadingElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const rotationRef = useRef(0);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const subheading = subheadingRef.current;
    const text = textRef.current;
    const canvasContainer = canvasContainerRef.current;

    if (!section || !heading || !subheading || !text || !canvasContainer) return;

    const ctx = gsap.context(() => {
      // Heading animations
      gsap.fromTo(
        heading,
        { opacity: 0, scale: 0.8 },
        {
          opacity: 1,
          scale: 1,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        subheading,
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        text,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.4,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Canvas container animation
      gsap.fromTo(
        canvasContainer,
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1,
          scale: 1,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Scroll-based rotation
      ScrollTrigger.create({
        trigger: section,
        start: 'top bottom',
        end: 'bottom top',
        scrub: 1,
        onUpdate: (self) => {
          rotationRef.current = self.progress * Math.PI * 4;
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="ac-motor"
      className="relative w-full min-h-screen bg-[#050505] py-20 overflow-hidden"
    >
      {/* Blueprint background */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: 'url(/blueprint-bg.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 240, 255, 0.5) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 240, 255, 0.5) 1px, transparent 1px)
            `,
            backgroundSize: '100px 100px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-8 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center min-h-[80vh]">
          {/* Left: 3D Model */}
          <div
            ref={canvasContainerRef}
            className="relative h-[500px] lg:h-[600px] order-2 lg:order-1"
            style={{ touchAction: 'pan-y' }}
          >
            <Canvas className="w-full h-full">
              <PerspectiveCamera makeDefault position={[8, 2, 8]} />
              <OrbitControls
                enableZoom={false}
                enablePan={false}
                autoRotate
                autoRotateSpeed={1}
                enableDamping={false}
              />
              <ambientLight intensity={0.6} />
              <pointLight position={[10, 10, 10]} intensity={1.5} color="#00F0FF" />
              <pointLight position={[-8, 5, 8]} intensity={1.2} color="#FFD700" />
              <pointLight position={[0, 8, -5]} intensity={1} color="#FFFFFF" />
              <directionalLight position={[5, 10, 5]} intensity={1} color="#FFFFFF" />
              <Suspense fallback={null}>
                <ACMotorModel rotationY={rotationRef.current} />
                <Environment preset="studio" />
              </Suspense>
            </Canvas>

            {/* Electric glow around canvas */}
            <div className="absolute inset-0 pointer-events-none">
              <div
                className="absolute inset-0 rounded-lg"
                style={{
                  boxShadow: 'inset 0 0 50px rgba(0, 240, 255, 0.2)',
                }}
              />
            </div>

            {/* Label */}
            <div className="absolute bottom-4 left-4 text-xs text-[#00F0FF]/60 tracking-widest">
              FIG. 1 - AC INDUCTION MOTOR
            </div>
          </div>

          {/* Right: Content */}
          <div className="space-y-8 order-1 lg:order-2">
            <h2
              ref={headingRef}
              className="text-5xl md:text-7xl font-black text-outline-cyan tracking-tight"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              ALTERNATING
              <span className="block">CURRENT</span>
            </h2>

            <h3
              ref={subheadingRef}
              className="text-2xl md:text-3xl text-[#00F0FF] tracking-wider"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              THE FUTURE OF ELECTRICITY
            </h3>

            <div ref={textRef} className="space-y-6">
              <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                Tesla's induction motor and polyphase alternating current system formed the 
                foundation of the modern electrical power grid. Unlike Edison's direct current 
                (DC), Tesla's AC could be transmitted over long distances with minimal power loss.
              </p>

              <p className="text-lg text-white/80 leading-relaxed" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                In 1888, George Westinghouse purchased Tesla's patents, leading to the "War of 
                Currents." Tesla's system ultimately won, powering the 1893 World's Columbian 
                Exposition in Chicago and the first hydroelectric plant at Niagara Falls in 1896.
              </p>

              {/* Key features */}
      <div className="grid grid-cols-2 gap-4 pt-6">
                <div className="border border-[#00F0FF]/30 p-4 rounded bg-[#00F0FF]/5">
                  <div className="text-[#00F0FF] text-sm mb-2">EFFICIENCY</div>
                  <div className="text-white/80 text-sm">Long-distance transmission with minimal loss</div>
                </div>
                <div className="border border-[#00F0FF]/30 p-4 rounded bg-[#00F0FF]/5">
                  <div className="text-[#00F0FF] text-sm mb-2">TRANSFORMERS</div>
                  <div className="text-white/80 text-sm">Voltage conversion for safe distribution</div>
                </div>
                <div className="border border-[#00F0FF]/30 p-4 rounded bg-[#00F0FF]/5">
                  <div className="text-[#00F0FF] text-sm mb-2">INDUCTION</div>
                  <div className="text-white/80 text-sm">Brushless motor with no moving contacts</div>
                </div>
                <div className="border border-[#00F0FF]/30 p-4 rounded bg-[#00F0FF]/5">
                  <div className="text-[#00F0FF] text-sm mb-2">POLYPHASE</div>
                  <div className="text-white/80 text-sm">Multiple AC currents for smooth rotation</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-20 w-32 h-32 border border-[#00F0FF]/20 rounded-full" />
      <div className="absolute bottom-20 left-20 w-24 h-24 border border-[#00F0FF]/20 rounded-full" />
    </section>
  );
};

export default ACMotor;
