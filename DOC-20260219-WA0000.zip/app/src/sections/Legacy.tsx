import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Legacy = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const quoteRef = useRef<HTMLQuoteElement>(null);
  const attributionRef = useRef<HTMLParagraphElement>(null);
  const towerRef = useRef<HTMLDivElement>(null);
  const honorsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const quote = quoteRef.current;
    const attribution = attributionRef.current;
    const tower = towerRef.current;
    const honors = honorsRef.current;

    if (!section || !quote || !attribution || !tower || !honors) return;

    const ctx = gsap.context(() => {
      // Tower silhouette animation
      gsap.fromTo(
        tower,
        { opacity: 0, y: 50 },
        {
          opacity: 0.15,
          y: 0,
          duration: 1.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Quote reveal animation (fade in + slide up)
      gsap.fromTo(
        quote,
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Attribution fade in
      gsap.fromTo(
        attribution,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          delay: 0.5,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 60%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Honors cards stagger animation
      const cards = honors.querySelectorAll('.honor-card');
      cards.forEach((card, i) => {
        gsap.fromTo(
          card,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: 0.3 + i * 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 50%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  const honors = [
    {
      year: '1960',
      title: 'The Tesla Unit',
      description: 'The SI unit of magnetic flux density is named in his honor.',
    },
    {
      year: '1975',
      title: 'Tesla Memorial Society',
      description: 'Founded to preserve his legacy and promote his inventions.',
    },
    {
      year: '2003',
      title: 'Tesla, Inc.',
      description: 'Electric vehicle company named to honor his vision.',
    },
    {
      year: '2013',
      title: 'Time 100',
      description: 'Named one of the 100 most significant figures of all time.',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="legacy"
      className="relative w-full min-h-screen bg-[#050505] py-20 overflow-hidden flex flex-col items-center justify-center"
    >
      {/* Wardenclyffe Tower silhouette */}
      <div
        ref={towerRef}
        className="absolute bottom-0 left-1/2 -translate-x-1/2 opacity-0 pointer-events-none"
      >
        <svg width="400" height="600" viewBox="0 0 400 600" className="text-[#00F0FF]">
          {/* Tower structure */}
          <path
            d="M200 0 L220 100 L210 150 L230 200 L215 250 L240 300 L220 350 L250 400 L225 450 L260 500 L230 550 L280 600 L120 600 L170 550 L140 500 L175 450 L150 400 L180 350 L160 300 L185 250 L170 200 L190 150 L180 100 Z"
            fill="currentColor"
            opacity="0.3"
          />
          {/* Dome */}
          <ellipse cx="200" cy="50" rx="60" ry="30" fill="currentColor" opacity="0.3" />
          {/* Base building */}
          <rect x="100" y="550" width="200" height="50" fill="currentColor" opacity="0.2" />
        </svg>
      </div>

      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center bottom, rgba(0, 240, 255, 0.1) 0%, transparent 60%)',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-8 text-center">
        {/* Main Quote */}
        <div className="mb-12 md:mb-20">
          <div className="text-4xl md:text-6xl text-[#00F0FF]/30 mb-2 md:mb-4">&ldquo;</div>
          <blockquote
            ref={quoteRef}
            className="text-xl sm:text-2xl md:text-4xl lg:text-5xl font-bold text-white leading-snug md:leading-tight px-2"
            style={{ fontFamily: 'Orbitron, sans-serif' }}
          >
            THE PRESENT IS THEIRS; I HAVE VERY LITTLE INTEREST IN IT. I WORK FOR THE FUTURE.
          </blockquote>
          <p
            ref={attributionRef}
            className="mt-6 md:mt-8 text-lg md:text-xl text-[#00F0FF] tracking-widest"
            style={{ fontFamily: 'Rajdhani, sans-serif' }}
          >
            — NIKOLA TESLA
          </p>
        </div>

        {/* Honors Grid */}
        <div ref={honorsRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mt-12 md:mt-16">
          {honors.map((honor, i) => (
            <div
              key={i}
              className="honor-card group p-4 md:p-6 border border-[#00F0FF]/20 rounded-lg bg-[#00F0FF]/5 hover:bg-[#00F0FF]/10 hover:border-[#00F0FF]/50 transition-all duration-300"
              data-cursor-hover
            >
              <div
                className="text-2xl md:text-3xl font-bold text-[#00F0FF] mb-2"
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                {honor.year}
              </div>
              <h4
                className="text-base md:text-lg font-semibold text-white mb-2"
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                {honor.title}
              </h4>
              <p className="text-xs md:text-sm text-white/60" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
                {honor.description}
              </p>
            </div>
          ))}
        </div>

        {/* Final tribute */}
        <div className="mt-16 md:mt-20 pt-8 md:pt-10 border-t border-[#00F0FF]/20 px-4">
          <p className="text-sm md:text-lg text-white/60 max-w-2xl mx-auto" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            Though he died alone and nearly penniless in 1943, Nikola Tesla&apos;s inventions 
            power our modern world. Every time you flip a light switch, charge your phone, 
            or connect to WiFi, you are living in the future he envisioned.
          </p>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 left-10 md:left-20 w-2 h-2 bg-[#00F0FF] rounded-full animate-pulse" />
      <div className="absolute top-40 right-10 md:right-32 w-1 h-1 bg-[#00F0FF] rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
      <div className="absolute bottom-40 left-10 md:left-32 w-1.5 h-1.5 bg-[#00F0FF] rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
    </section>
  );
};

export default Legacy;
