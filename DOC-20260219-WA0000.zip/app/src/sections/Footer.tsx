import { Zap, Github, Twitter, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative w-full bg-[#050505] border-t border-[#00F0FF]/20 py-12">
      {/* Electric line animation */}
      <div className="absolute top-0 left-0 right-0 h-px overflow-hidden">
        <div
          className="h-full w-1/3 bg-gradient-to-r from-transparent via-[#00F0FF] to-transparent animate-pulse"
          style={{
            animation: 'slide 3s linear infinite',
          }}
        />
      </div>

      <style>{`
        @keyframes slide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }
      `}</style>

      <div className="max-w-7xl mx-auto px-8 lg:px-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-center">
          {/* Logo & Tagline */}
          <div className="text-center md:text-left">
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-3 group"
              data-cursor-hover
            >
              <Zap className="w-8 h-8 text-[#00F0FF] group-hover:animate-pulse" />
              <span
                className="text-2xl font-bold text-white group-hover:text-[#00F0FF] transition-colors"
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                TESLA
              </span>
            </button>
            <p className="mt-4 text-white/50 text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              The Master of Lightning
            </p>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h4
              className="text-sm text-[#00F0FF] tracking-widest mb-4"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              EXPLORE
            </h4>
            <nav className="flex flex-wrap justify-center gap-6">
              {['Hero', 'The Man', 'AC Motor', 'Tesla Coil', 'Radio', 'Legacy'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase().replace(' ', '-')}`}
                  className="text-white/60 hover:text-[#00F0FF] transition-colors text-sm"
                  style={{ fontFamily: 'Rajdhani, sans-serif' }}
                  data-cursor-hover
                >
                  {link}
                </a>
              ))}
            </nav>
          </div>

          {/* Social & Credits */}
          <div className="text-center md:text-right">
            <h4
              className="text-sm text-[#00F0FF] tracking-widest mb-4"
              style={{ fontFamily: 'Orbitron, sans-serif' }}
            >
              CONNECT
            </h4>
            <div className="flex justify-center md:justify-end gap-4">
              {[
                { icon: Twitter, href: '#' },
                { icon: Github, href: '#' },
                { icon: Linkedin, href: '#' },
              ].map(({ icon: Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="w-10 h-10 border border-[#00F0FF]/30 rounded-full flex items-center justify-center text-white/60 hover:text-[#00F0FF] hover:border-[#00F0FF] hover:shadow-[0_0_15px_rgba(0,240,255,0.3)] transition-all"
                  data-cursor-hover
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            &copy; {currentYear} Nikola Tesla Tribute. All rights reserved.
          </p>
          <p className="text-white/40 text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            Designed with <span className="text-[#00F0FF]">electricity</span> by KUSA
          </p>
        </div>

        {/* Final electric touch */}
        <div className="mt-8 text-center">
          <p
            className="text-xs text-[#00F0FF]/30 tracking-[0.5em] uppercase"
            style={{ fontFamily: 'Orbitron, sans-serif' }}
          >
            The Future Is His
          </p>
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute bottom-4 left-4 w-8 h-8 border-l border-b border-[#00F0FF]/20" />
      <div className="absolute bottom-4 right-4 w-8 h-8 border-r border-b border-[#00F0FF]/20" />
    </footer>
  );
};

export default Footer;
