import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const CustomCursor = () => {
  const cursorRef = useRef<HTMLDivElement>(null);
  const cursorDotRef = useRef<HTMLDivElement>(null);
  const trailsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    // Check if touch device
    const isTouchDevice = window.matchMedia('(pointer: coarse)').matches;
    if (isTouchDevice) return;

    const cursor = cursorRef.current;
    const cursorDot = cursorDotRef.current;
    if (!cursor || !cursorDot) return;

    const trails: HTMLDivElement[] = [];
    const trailCount = 5;

    // Create trail elements
    for (let i = 0; i < trailCount; i++) {
      const trail = document.createElement('div');
      trail.className = 'fixed pointer-events-none z-[9998] rounded-full';
      trail.style.width = `${8 - i}px`;
      trail.style.height = `${8 - i}px`;
      trail.style.backgroundColor = `rgba(0, 240, 255, ${0.5 - i * 0.08})`;
      trail.style.boxShadow = `0 0 ${10 - i}px rgba(0, 240, 255, ${0.6 - i * 0.1})`;
      document.body.appendChild(trail);
      trails.push(trail);
    }
    trailsRef.current = trails;

    const onMouseMove = (e: MouseEvent) => {
      // Main cursor
      gsap.to(cursor, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.08,
        ease: 'power2.out',
      });

      // Center dot
      gsap.to(cursorDot, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.05,
        ease: 'power2.out',
      });

      // Trails with staggered delay
      trails.forEach((trail, i) => {
        gsap.to(trail, {
          x: e.clientX,
          y: e.clientY,
          duration: 0.15 + i * 0.05,
          ease: 'power2.out',
        });
      });
    };

    const onMouseEnter = () => {
      gsap.to([cursor, cursorDot, ...trails], {
        opacity: 1,
        duration: 0.3,
      });
    };

    const onMouseLeave = () => {
      gsap.to([cursor, cursorDot, ...trails], {
        opacity: 0,
        duration: 0.3,
      });
    };

    // Hover effects for interactive elements
    const addHoverEffects = () => {
      const interactiveElements = document.querySelectorAll('a, button, [data-cursor-hover]');
      
      interactiveElements.forEach((el) => {
        el.addEventListener('mouseenter', () => {
          gsap.to(cursor, {
            scale: 1.5,
            borderColor: '#00F0FF',
            duration: 0.3,
          });
        });
        
        el.addEventListener('mouseleave', () => {
          gsap.to(cursor, {
            scale: 1,
            borderColor: 'rgba(0, 240, 255, 0.8)',
            duration: 0.3,
          });
        });
      });
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseenter', onMouseEnter);
    document.addEventListener('mouseleave', onMouseLeave);
    
    // Add hover effects after a short delay to ensure DOM is ready
    setTimeout(addHoverEffects, 1000);

    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseenter', onMouseEnter);
      document.removeEventListener('mouseleave', onMouseLeave);
      trails.forEach((trail) => trail.remove());
    };
  }, []);

  // Don't render on touch devices
  if (typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches) {
    return null;
  }

  return (
    <>
      {/* Main cursor ring */}
      <div
        ref={cursorRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2 mix-blend-difference"
        style={{
          width: '40px',
          height: '40px',
          border: '2px solid rgba(0, 240, 255, 0.8)',
          borderRadius: '50%',
          opacity: 0,
        }}
      />
      {/* Center dot */}
      <div
        ref={cursorDotRef}
        className="fixed pointer-events-none z-[9999] -translate-x-1/2 -translate-y-1/2"
        style={{
          width: '6px',
          height: '6px',
          backgroundColor: '#00F0FF',
          borderRadius: '50%',
          opacity: 0,
          boxShadow: '0 0 10px #00F0FF',
        }}
      />
    </>
  );
};

export default CustomCursor;
